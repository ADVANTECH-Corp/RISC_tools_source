#include <stdio.h>
#include <stdlib.h>
#include <stdarg.h>
#include <unistd.h>  /* UNIX standard function definitions */
#include <fcntl.h>   /* File control definitions */
#include <errno.h>   /* Error number definitions */
#include <pthread.h>
#include <sys/ioctl.h>
#include <linux/serial.h>
#include <linux/serial_reg.h>
#include <time.h>
#include <string.h>
#include <strings.h>
#include <getopt.h>
#include <signal.h>
#include <sys/stat.h>

/* Driver-specific ioctls: */
#define TIOCGRS485      0x542E
#define TIOCSRS485      0x542F
int main(int argc, char *argv[])
{
	int PortHandle = -1;
	struct serial_rs485 rs485conf;
	PortHandle = open((char *)argv[1], O_RDWR | O_NOCTTY | O_NDELAY);
	if(PortHandle == -1) {
                printf("Unable to open %s\n", (char *)argv[1]);
                return -1;
        }

	/* Set RS485 mode: */
	rs485conf.flags |= SER_RS485_ENABLED;
	if (argv[2]){
		rs485conf.flags |= SER_RS485_RTS_AFTER_SEND;
		printf("Enable SER_RS485_RTS_AFTER_SEND\n");
	}
	if (ioctl (PortHandle, TIOCSRS485, &rs485conf) < 0) {
		printf("Cannot set 485 flags\n");
		return -1;
	}
	printf("Enable RS-485 success\n");

	return 0;
}
